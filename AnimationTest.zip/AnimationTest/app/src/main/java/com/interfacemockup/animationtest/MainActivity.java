package com.interfacemockup.animationtest;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

public class MainActivity extends AppCompatActivity {

    private ImageView slika;
    private Button myButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        slika = (ImageView)findViewById(R.id.myImage);
        myButton = (Button)findViewById(R.id.moj_button) ;




        yoyoAnimacija();

    }

    public void yoyoAnimacija(){
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                YoYo.with(Techniques.FlipInY)
                        .duration(700)
                        .repeat(0)
                        .playOn(slika);


            }
        });

    }




}
